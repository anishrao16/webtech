package pojo;

import java.util.ArrayList;

public class Elevator {

    enum directionState {UP,DOWN,STOP};
    enum powerState {ON,OFF};
    enum doorState {OPEN,CLOSED};

    String id;
    Integer currentFloor;
    Integer maxFloor;
    Integer minFloor;
    ArrayList<Integer> floors;

    Integer maxLoad;
    Integer currentLoad;

    directionState state;
    powerState power;
    doorState doors;

    public Elevator() {
        this.id ="";
        currentFloor=0;
        maxFloor=0;
        minFloor=0;
        maxFloor=0;
        currentLoad=0;
        state = directionState.STOP;
        power = powerState.OFF;
        doors = doorState.CLOSED;
        floors = new ArrayList<Integer>();

    }

    public Elevator(String id, Integer currentFloor, Integer maxFloor, Integer minFloor) {
        this.id = id;
        this.currentFloor = currentFloor;
        this.maxFloor = maxFloor;
        this.minFloor = minFloor;
        currentLoad=0;
        state = directionState.STOP;
        power = powerState.OFF;
        doors = doorState.CLOSED;
        floors = new ArrayList<Integer>();
    }

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }

    public Integer getCurrentFloor() {
        return currentFloor;
    }

    public void setCurrentFloor(Integer currentFloor) {
        this.currentFloor = currentFloor;
    }

    public Integer getMaxFloor() {
        return maxFloor;
    }

    public void setMaxFloor(Integer maxFloor) {
        this.maxFloor = maxFloor;
    }

    public Integer getMinFloor() {
        return minFloor;
    }

    public void setMinFloor(Integer minFloor) {
        this.minFloor = minFloor;
    }

    public ArrayList<Integer> getFloors() {
        return floors;
    }

    public void setFloors(ArrayList<Integer> floors) {
        this.floors = floors;
    }

    public Integer getMaxLoad() {
        return maxLoad;
    }

    public void setMaxLoad(Integer maxLoad) {
        this.maxLoad = maxLoad;
    }

    public Integer getCurrentLoad() {
        return currentLoad;
    }

    public void setCurrentLoad(Integer currentLoad) {
        this.currentLoad = currentLoad;
    }

    public directionState getState() {
        return state;
    }

    public void setState(directionState state) {
        this.state = state;
    }

    public powerState getPower() {
        return power;
    }

    public void setPower(powerState power) {
        this.power = power;
    }

    public doorState getDoors() {
        return doors;
    }

    public void setDoors(doorState doors) {
        this.doors = doors;
    }
}
