package university_pojo;

import java.util.ArrayList;
import java.util.Iterator;

public class University {

	private String name;
	private String address;
	private String grade;
	
	ArrayList <Department> departmentList;
	ArrayList <College> collegeList;
	public University() {
		super();
		
	}
	
	public University(String name, String address, String grade) {
		super();
		this.name = name;
		this.address = address;
		this.grade = grade;
	}

	public University(String name, String address, String grade, ArrayList<Department> departmentList,
			ArrayList<College> collegeList) {
		super();
		this.name = name;
		this.address = address;
		this.grade = grade;
		this.departmentList = departmentList;
		this.collegeList = collegeList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public String getGrade() {
		return grade;
	}

	public void setGrade(String grade) {
		this.grade = grade;
	}

	public ArrayList<Department> getDepartmentList() {
		return departmentList;
	}

	public void setDepartmentList(ArrayList<Department> departmentList) {
		this.departmentList = departmentList;
	}

	public ArrayList<College> getCollegeList() {
		return collegeList;
	}

	public void setCollegeList(ArrayList<College> collegeList) {
		this.collegeList = collegeList;
	}
	
	public void showCourseDetails(String courseName)
	{
		Iterator dept_itr=departmentList.iterator(); 
		Iterator college_itr=collegeList.iterator();
		Integer studentCount = 0;
		Department tdept = null;
		Course tcourse = null;
		//---loop through departments of university
		  while(dept_itr.hasNext()){  
			  tdept = (Department) dept_itr.next();	
			  tcourse = tdept.getCourseByName(courseName);
			  if(tcourse!=null)
			  {
				  studentCount+= tcourse.getNoOfStudents();
			  }
		  }
		  
		  //-------loop through colleges
		  College tcollege = null;
		  while(college_itr.hasNext()){  
			  tcollege = (College) college_itr.next();	
			  tcourse = tcollege.getCourse(courseName);
			  if(tcourse !=null)
			  {
				  studentCount+= tcourse.getNoOfStudents();
			  }
		  }
		  
		  System.out.println(courseName + "\t" + studentCount);
		  
	}
	

	public void showRevenueforCourse(String courseName)
	{
			Iterator dept_itr=departmentList.iterator(); 
			Iterator college_itr=collegeList.iterator();
			Integer courseRevenue = 0;
			Department tdept = null;
			Course tcourse = null;
			  while(dept_itr.hasNext()){  
				  tdept = (Department) dept_itr.next();	
				  tcourse = tdept.getCourseByName(courseName);
				  if(tcourse!=null)
				  {
					  courseRevenue+= tcourse.getRevenue();
				  }
			  }
			  
			  College tcollege = null;
			  while(college_itr.hasNext()){  
				  tcollege = (College) college_itr.next();	
				  tcourse = tcollege.getCourse(courseName);
				  if(tcourse !=null)
				  {
					  courseRevenue+= tcourse.getRevenue();
				  }
			  }
			  
			  System.out.println(courseName + "\t" + courseRevenue);
		
	}
	
	
}
