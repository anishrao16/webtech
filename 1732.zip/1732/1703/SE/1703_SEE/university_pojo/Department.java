package university_pojo;

import java.util.ArrayList;
import java.util.Iterator;

public class Department {
	private String name;
	private String HOD_Name;
	
	ArrayList <Course> courseList;

	public Department() {
		super();
	}
	
	public Department(String name) {
		super();
		this.name = name;
	}

	public Department(String name, String hOD_Name, ArrayList<Course> courseList) {
		super();
		this.name = name;
		HOD_Name = hOD_Name;
		this.courseList = courseList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHOD_Name() {
		return HOD_Name;
	}

	public void setHOD_Name(String hOD_Name) {
		HOD_Name = hOD_Name;
	}

	public ArrayList<Course> getCourseList() {
		return courseList;
	}

	public void setCourseList(ArrayList<Course> courseList) {
		this.courseList = courseList;
	}
	
	public Course getCourseByName(String courseName)
	{
		
		Iterator itr=courseList.iterator();  		
		Course tcourse = null;
		  while(itr.hasNext()){  
			  tcourse = (Course) itr.next();	
			  if(tcourse.getName()==courseName)
			  {
				  return tcourse;
			  }
		  } 
		  return tcourse;
	}
	
	public void addCourse(Course course)
	{
		if(this.getCourseByName(course.getName())!=null)
		{
			courseList.add(course);
		}
	}
	
	

}
