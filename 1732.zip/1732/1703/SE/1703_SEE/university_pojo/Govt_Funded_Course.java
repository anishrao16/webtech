package university_pojo;

import java.util.ArrayList;

public class Govt_Funded_Course extends Course{
	String govtSchemeName;
	Integer subsidyAmount;
	public Govt_Funded_Course() {
		super();
	}
	public Govt_Funded_Course(String govtSchemeName, Integer subsidyAmount) {
		super();
		this.govtSchemeName = govtSchemeName;
		this.subsidyAmount = subsidyAmount;
	}
	public Govt_Funded_Course(String name, Integer fee, ArrayList<Student> studentList) {
		super(name, fee, studentList);
		// TODO Auto-generated constructor stub
	}
	public Govt_Funded_Course(String name, Integer fee, ArrayList<Student> studentList,String govtSchemeName, Integer subsidyAmount) {
		super(name, fee, studentList);
		this.govtSchemeName = govtSchemeName;
		this.subsidyAmount = subsidyAmount;
	}
	public Govt_Funded_Course(String name) {
		super(name);
		//-------------------------------------------------------
	}
	public String getGovtSchemeName() {
		return govtSchemeName;
	}
	public void setGovtSchemeName(String govtSchemeName) {
		this.govtSchemeName = govtSchemeName;
	}
	public Integer getSubsidyAmount() {
		return subsidyAmount;
	}
	public void setSubsidyAmount(Integer subsidyAmount) {
		this.subsidyAmount = subsidyAmount;
	}
	
	
	
	
	
}
