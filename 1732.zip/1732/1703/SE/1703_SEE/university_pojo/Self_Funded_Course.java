package university_pojo;

import java.util.ArrayList;

public class Self_Funded_Course extends Course{
	
	String bankAccountNo;
	String bankName;
	public Self_Funded_Course() {
		super();
	}
	public Self_Funded_Course(String bankAccountNo, String bankName) {
		super();
		this.bankAccountNo = bankAccountNo;
		this.bankName = bankName;
	}
	public Self_Funded_Course(String name, Integer fee, ArrayList<Student> studentList,String bankAccountNo, String bankName) {
		super(name, fee, studentList);
		this.bankAccountNo = bankAccountNo;
		this.bankName = bankName;
		// TODO Auto-generated constructor stub
	}
	public Self_Funded_Course(String name) {
		super(name);
		// TODO Auto-generated constructor stub
	}
	public String getBankAccountNo() {
		return bankAccountNo;
	}
	public void setBankAccountNo(String bankAccountNo) {
		this.bankAccountNo = bankAccountNo;
	}
	public String getBankName() {
		return bankName;
	}
	public void setBankName(String bankName) {
		this.bankName = bankName;
	}
	
	
	

}
