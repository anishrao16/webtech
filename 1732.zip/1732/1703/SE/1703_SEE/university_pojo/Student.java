package university_pojo;

public class Student {
	String rollNo;
	String name;
	String gender;
	String dateOfBirth;
	
	public Student() {
		super();
	}
	

	public Student(String name) {
		super();
		this.name = name;
	}
	

	public Student(String rollNo, String name, String gender, String dateOfBirth) {
		super();
		this.rollNo = rollNo;
		this.name = name;
		this.gender = gender;
		this.dateOfBirth = dateOfBirth;
	}


	public String getRollNo() {
		return rollNo;
	}

	public void setRollNo(String rollNo) {
		this.rollNo = rollNo;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getGender() {
		return gender;
	}

	public void setGender(String gender) {
		this.gender = gender;
	}

	public String getDateOfBirth() {
		return dateOfBirth;
	}

	public void setDateOfBirth(String dateOfBirth) {
		this.dateOfBirth = dateOfBirth;
	}	
	

}
