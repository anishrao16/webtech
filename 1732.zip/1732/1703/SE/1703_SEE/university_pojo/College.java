package university_pojo;

import java.util.ArrayList;
import java.util.Iterator;

public class College {
	private String name;
	private String address;
	
	ArrayList <Department> departmentList;

	public College() {
		super();
	}
	
	public College(String name) {
		super();
		this.name = name;
		
	}

	public College(String name, String address, ArrayList<Department> departmentList) {
		super();
		this.name = name;
		this.address = address;
		this.departmentList = departmentList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getAddress() {
		return address;
	}

	public void setAddress(String address) {
		this.address = address;
	}

	public ArrayList<Department> getDepartmentList() {
		return departmentList;
	}

	public void setDepartmentList(ArrayList<Department> departmentList) {
		this.departmentList = departmentList;
	}
	
	public Course getCourse(String courseName)
	{
		Iterator dept_itr=departmentList.iterator(); 
		
		Department tdept = null;
		Course tcourse = null;
		  while(dept_itr.hasNext()){  
			  tdept = (Department) dept_itr.next();	
			  tcourse = tdept.getCourseByName(courseName);
			  if(tcourse!=null)
			  {
				 return tcourse;
			  }
		  }
		  return tcourse;
		  
	}

}
