package university_pojo;

import java.io.File;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.Scanner;

public class Course {
	String name;
	Integer fee;
	
	ArrayList<Student> studentList;

	public Course() {
		super();
	}

	public Course(String name) {
		super();
		this.name = name;
	}

	public Course(String name, Integer fee) {
		super();
		this.name = name;
		this.fee = fee;
	}

	public Course(String name, Integer fee, ArrayList<Student> studentList) {
		super();
		this.name = name;
		this.fee = fee;
		this.studentList = studentList;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Integer getFee() {
		return fee;
	}

	public void setFee(Integer fee) {
		this.fee = fee;
	}

	public ArrayList<Student> getStudentList() {
		return studentList;
	}

	public void setStudentList(ArrayList<Student> studentList) {
		this.studentList = studentList;
	}
	
	public static ArrayList<Course> loadCourses(String filename)
	{
		ArrayList<Course> courseList = new ArrayList<Course>();
		String line;
		String[] data; 
		try
		{
			Scanner fr = new Scanner(new File(filename));
			while(fr.hasNextLine())
			{
				
				line  = fr.nextLine();
				data = line.split(",");
				courseList.add(new Course(data[0],Integer.parseInt(data[1])));
				
			}
	
		}
		catch( Exception fnex)
		{
			fnex.printStackTrace();
		}
		
		return courseList;
	}
	
	public static void printCourseList(ArrayList<Course> courseList)
	{
		
		Iterator itr=courseList.iterator();  
		
		Course tcourse;
		  while(itr.hasNext()){  
			  tcourse = (Course) itr.next();	
		   System.out.print(tcourse.getName().toString() + "\t");
		   System.out.print(tcourse.getFee());
		   System.out.println();
		  }  
	}
	
	public Integer getNoOfStudents()
	{
		return studentList.size();
	}
	
	public Integer getRevenue()
	{
		return this.getNoOfStudents()*fee;
	}
	

}
