package application;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.Scanner;

import university_pojo.*;

public class MainApplication {

	public static University univ = new University("GU","Goa","B");
	public static void main(String[] args) {
		
		initializeData();
		
		univ.showCourseDetails("BCA");
		univ.showRevenueforCourse("BCA");
	}
	
	public static void initializeData()
	{
		ArrayList <Department> departmentList = new ArrayList <Department>();
		Department d = new Department("CompSci");
		
		ArrayList <Course> courseList = Course.loadCourses("src/courseList.txt");
		d.setCourseList(courseList);
		Course nc = d.getCourseByName("BCA");
		ArrayList<Student> sl = new ArrayList<Student>();
		sl.add(new Student("s1"));
		sl.add(new Student("s2"));
		nc.setStudentList(sl);
		departmentList.add(d);		
		univ.setDepartmentList(departmentList);
		
		ArrayList <College> clist = new ArrayList <College>();
		College c = new College("College A");
		ArrayList <Department> cdepts = new ArrayList <Department>();
		Department d2 = new Department("computer");
		
		ArrayList <Course> collcourse = Course.loadCourses("src/courseList.txt");
		d2.setCourseList(collcourse);
		Course nc2 = d.getCourseByName("BCA");
		ArrayList<Student> sl0 = new ArrayList<Student>();
		sl0.add(new Student("cs1"));
		nc2.setStudentList(sl0);
		cdepts.add(d2);		
		c.setDepartmentList(cdepts);		
		clist.add(c );		
		univ.setCollegeList(clist);
		
		
		
		
	}

}
